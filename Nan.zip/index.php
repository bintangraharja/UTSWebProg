<?php
    header('location: ./View/Home.php')
?>