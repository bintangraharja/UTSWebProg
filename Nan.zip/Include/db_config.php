<?php
$host = "localhost";
$username = "root";
$dbname = "uts_webprog";
$password = "";

$db = mysqli_connect($host, $username, $password, $dbname);
?>